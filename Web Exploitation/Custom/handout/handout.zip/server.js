import jwt from 'jsonwebtoken';
import cookieParser from 'cookie-parser';
import express from 'express';
import session from 'express-session';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import puppeteer from 'puppeteer';
import dotenv from 'dotenv';

dotenv.config();

const __dirname = dirname(fileURLToPath(import.meta.url));
const app = express();
const host = '0.0.0.0';
const port = 4004;
const publicUrl = `http://${host}:${port}`;

const SECRET_KEY = "REDACTED";

const tok = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJyb2xlIjoidXNlciIsInVzZXJuYW1lIjoidXNlciJ9.uonasDCvXCp2rnlUlrx6aUOk0GjUpAGLsFIhZgmF0lw";

app.use(cookieParser());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: 'REDACTED',
  resave: false,
  saveUninitialized: true
}));

const ADMIN_SECRET = "Spark{F4ke_fl4g_f0r_t3st1ng}";
const userThemes = new Map();

app.use((req, res, next) => {

  const token = req.cookies.token;

  if (!token) {
    return res.status(401).send('Unauthorized!');
  }

  try {
    const decoded = jwt.verify(token, SECRET_KEY, { algorithms: ['HS256'] });

    if (decoded.role !== 'admin') {
      return res.status(403).send('Unauthorized!');
    }

    req.user = decoded;
    next();
  } catch (err) {
    return res.status(401).send('Unauthorized!');
  }
});


app.use(express.static(join(__dirname, 'public')));

function generateAdminToken() {
  const payload = {
    role: 'admin',
    username: 'admin',
  };

  return jwt.sign(payload, SECRET_KEY, { algorithm: 'HS256' });
}

async function adminBot(themeId) {
  const browser = await puppeteer.launch({
    headless: 'new',
    args: ['--no-sandbox']
  });
  const token = generateAdminToken();
  try {
    const page = await browser.newPage();

    await page.setCookie({
      name: 'admin',
      value: 'REDACTED',
      domain: host,
      httpOnly: true,
    });
    await page.setCookie({
      name: 'token',
      value: token,
      domain: host,
      httpOnly: true,
    });

    await page.goto(`${publicUrl}/preview/${themeId}`);
    await new Promise(resolve => setTimeout(resolve, 3000));
  } finally {
    await browser.close();
  }
}

app.get('/', (req, res) => {
  res.sendFile(join(__dirname, 'public', 'index.html'));
});

app.post('/submit', (req, res) => {
  const { name, theme } = req.body;
  const themeId = Date.now().toString(36) + Math.random().toString(36).substr(2);
  
  userThemes.set(themeId, {
    name,
    theme,
    views: 0
  });

  adminBot(themeId);

  res.redirect(`/preview/${themeId}`);
});

app.get('/preview/:themeId', (req, res) => {
  const themeData = userThemes.get(req.params.themeId);
  if (!themeData) {
    return res.status(404).send('Theme not found');
  }

  const isAdmin = ((req.cookies.admin === 'REDACTED') && (req.connection.remoteAddress == "127.0.0.1"));
  themeData.views++;

  res.send(`
    <!DOCTYPE html>
    <html>
    <head>
      <title>Theme Preview</title>
      <style>
        ${themeData.theme}
      </style>
    </head>
    <body>
      <div class="profile">
        <h1>Welcome, ${themeData.name}!</h1>
        <p>Theme views: ${themeData.views}</p>
        ${isAdmin ? `<div id="admin-panel" data-content="${ADMIN_SECRET}"></div>` : ''}
      </div>
    </body>
    </html>
  `);
});

app.listen(port, host, () => {
  console.log(`Server running at ${publicUrl}`);
});

