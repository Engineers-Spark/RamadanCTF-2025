package com.megacorp.action;

import java.util.ArrayList;
import java.util.List;

public class ProductAction {
    private List<String> products = new ArrayList<>();
    
    public String execute() {
        products.add("Secure Server 2000");
        products.add("MegaFirewall Pro");
        products.add("DataVault Ultimate");
        products.add("bou3rada fach ta3mil honi ?")
        return "success";
    }
    
    public List<String> getProducts() {
        return products;
    }
}